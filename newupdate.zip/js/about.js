// var timeoutme;
// $(document).ready(function () {
//
//     $(".searchbox").on('click',function(){
//         $('.searchoverlay').removeClass('hide');
//         $('.searchform').removeClass('hide')
//         $('#search').focus();
//     });
//
//     $('.searchoverlay').on('click',function(){
//         $('.searchoverlay').addClass('hide');
//         $('.searchform').addClass('hide')
//     });
//
//     $(".closesearchbox").on('click',function(){
//         $('.searchoverlay').addClass('hide');
//         $('.searchform').addClass('hide')
//     });
//
//     $('.dropmetriger').on('mouseenter', function () {
//         clearTimeout(timeoutme);
//         $('.dropme').removeClass('hide');
//     }).on('mouseleave', function () {
//         timeoutme = setTimeout(function () {
//             $('.dropme').addClass('hide');
//         }, 500)
//     });
//     $('.dropme').on('mouseenter', function () {
//         clearTimeout(timeoutme);
//         $('.dropme').removeClass('hide');
//     }).on('mouseleave', function () {
//         timeoutme = setTimeout(function () {
//             $('.dropme').addClass('hide');
//         }, 500)
//     })
// });