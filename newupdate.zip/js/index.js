// var timeoutme;
// $(document).ready(function(){
//     $('.dropmetriger').on('mouseenter',function(){
//         clearTimeout(timeoutme);
//         $('.dropme').removeClass('hide');
//     }).on('mouseleave',function(){
//         timeoutme=setTimeout(function(){
//             $('.dropme').addClass('hide');
//         },500)
//
//     })
//     $('.dropme').on('mouseenter',function(){
//         clearTimeout(timeoutme);
//         $('.dropme').removeClass('hide');
//     }).on('mouseleave',function(){
//         timeoutme=setTimeout(function(){
//             $('.dropme').addClass('hide');
//         },500)
//     })
// });